import java.util.Scanner;

public class Binarytodecimal{
    public static void main(String[] args){
      Scanner scan=new Scanner(System.in);
      System.out.print("Enter a binary number:");
      String a=scan.next();
 
      int b=Integer.parseInt(a,2);

      System.out.print("Decimal Number:"+Integer.toString(b));
  }
}
      