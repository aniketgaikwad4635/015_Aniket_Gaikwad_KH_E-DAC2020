
import java.util.Scanner;
import java.util.*;

public class Multiplication {
	

	public static void main(String args[]) {
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter First number:");
		int a=sc.nextInt();
		System.out.print("Enter Second number:");
		int b=sc.nextInt();
		
		int z=a * b;
		System.out.print(""+a+"x"+b+"="+z);

	}

}