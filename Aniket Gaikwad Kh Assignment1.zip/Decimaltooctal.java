import java.util.Scanner;

public class Decimaltooctal{
  public static void main(String[] args){
       Scanner scan=new Scanner(System.in);
       System.out.print("Enter a Decimal number:");
       String a=scan.next();

       int b=Integer.parseInt(a,10);

       System.out.print("Octal number is:"+Integer.toOctalString(b));
   }
}