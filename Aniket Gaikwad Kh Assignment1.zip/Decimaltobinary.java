import java.util.Scanner;

public class Decimaltobinary{
  public static void main(String[] args){
     Scanner scan = new Scanner(System.in);
     System.out.print("Enter a decimal number:");
     String a = scan.next();

     int b = Integer.parseInt(a,10);
  
     System.out.print("Binary number is:"+Integer.toBinaryString(b));

   }
}    
