import java.util.Scanner;

public class Binarytohexadecimal{
  public static void main(String[] args){
    Scanner scan= new Scanner(System.in);
     System.out.print("Enter a Binary Number:");
     String a=scan.next();
 
     int b=Integer.parseInt(a,2);

     System.out.print("HexaDecimal value:"+Integer.toHexString(b));
  }
} 

   