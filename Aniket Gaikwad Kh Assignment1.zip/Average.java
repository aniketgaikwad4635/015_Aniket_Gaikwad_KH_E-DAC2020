import java.util.Scanner;

public class Average{
  public static void main(String[] args){
    Scanner scan=new Scanner(System.in);
    System.out.print("Enter first number:");
    int a=scan.nextInt();
    System.out.print("Enter second number:");
    int b=scan.nextInt();
    System.out.print("Enter third number:");
    int c=scan.nextInt();

    int total=a+b+c;
    double avg=total/3.0;

    System.out.println("Average="+avg);
  }
}


    