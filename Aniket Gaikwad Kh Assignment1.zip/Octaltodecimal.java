import java.util.Scanner;
  public class Octaltodecimal{
    public static void main(String[] args){
      Scanner scan=new Scanner(System.in);
      System.out.print("Enter any octal number:");
      String a=scan.next();
     
      int b=Integer.parseInt(a,8);

      System.out.print("Equivalent decimal number:"+Integer.toString(b));
   }
}     