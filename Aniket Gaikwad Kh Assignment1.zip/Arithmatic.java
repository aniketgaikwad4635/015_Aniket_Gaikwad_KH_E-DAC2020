import java.util.*;

public class Arithmatic{
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);

        System.out.print("Enter first input:");
        int a=input.nextInt();

        System.out.print("Enter second input:");
        int b=input.nextInt();
        
       int add=a+b;
       int sub=a-b;
       int mul=a*b;
       int div=a/b;
       int mod=a%b;
       
        System.out.println(""+a+"+"+b+"="+add);
        System.out.println(""+a+"-"+b+"="+sub);
        System.out.println(""+a+"x"+b+"="+mul);
        System.out.println(""+a+"/"+b+"="+div);
        System.out.println(""+a+"mod"+b+"="+mod);
  }
}
