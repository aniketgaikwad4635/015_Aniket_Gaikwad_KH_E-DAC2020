import java.util.Scanner;

public class Swap{
 public static void main(String[] args){
   Scanner scan=new Scanner(System.in);
   System.out.print("Enter first number:");
   int a=scan.nextInt();
   System.out.print("Enter second number:");
   int b=scan.nextInt();


   System.out.println("Before swaping");  
   System.out.println("A="+a+" B="+b);

   int temp=a;
   a=b;
   b=temp;

   System.out.println("After swaping");  
   System.out.println("A="+a+" B="+b);
   
  }
}
   