import java.util.Scanner;

public class Rectangle{
  public static void main(String[] args){
   Scanner scan=new Scanner(System.in);
   System.out.print("Enter width of rectangle:");
   double w=scan.nextDouble();
   System.out.print("Enter height of rectangle:");
   double h=scan.nextDouble();
 
   double area=w*h;
   double perimeter=2*(w+h);

   System.out.println("Area is "+w+"*"+h+"="+area);
   System.out.println("Perimeter is 2*("+w+"+"+h+")="+perimeter);
  }
}