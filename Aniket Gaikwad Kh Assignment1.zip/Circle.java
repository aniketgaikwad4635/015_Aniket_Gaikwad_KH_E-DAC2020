import java.util.Scanner;
import java.lang.Math.*;

public class Circle{
  public static void main(String[] args){
    System.out.print("Radius:");
    Scanner input=new Scanner(System.in);
     double r=input.nextDouble();
     double pi=Math.PI;
     double per=2*pi*r;
     double area=pi*r*r;
     
      System.out.println("Perimeter="+ per);
      System.out.println("Area="+ area);
  }
}