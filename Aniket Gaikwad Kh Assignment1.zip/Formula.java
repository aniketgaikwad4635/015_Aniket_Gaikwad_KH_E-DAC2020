public class Formula{

 public static void main(String[] args){

   double n=4.0, a=1,b=1.0/3,c=1.0/5,d=1.0/7,e=1.0/9,f=1.0/11;
   double ans=n*((a - b + c - d + e - f));
   System.out.println(ans);
 }
}