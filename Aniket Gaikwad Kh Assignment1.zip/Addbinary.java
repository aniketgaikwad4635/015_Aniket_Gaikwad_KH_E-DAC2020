import java.util.Scanner;

public class Addbinary{
  public static void main(String[] args){
     Scanner scan = new Scanner(System.in);
     System.out.print("Enter first binary number:");
     String a = scan.next();

     System.out.print("Enter second binary number:");
     String b = scan.next();

     int c = Integer.parseInt(a,2);
     int d = Integer.parseInt(b,2);

     int e = c+d;
  
     System.out.println("Sum of two binary numbers:"+Integer.toBinaryString(e));

   }
}    

   