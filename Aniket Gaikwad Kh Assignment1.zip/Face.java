import java.util.*;

public class Face{
    public static void main(String[] args){
       System.out.println(" " + "+" + "\"" + "\"" + "\"" + "\"" + "\"" + "+" );
       System.out.println("[| o o |]");
       System.out.println(" |  ^  |");
       System.out.println(" | '-' |");
       System.out.println(" " + "+" + "-----" + "+" );
  }
}

