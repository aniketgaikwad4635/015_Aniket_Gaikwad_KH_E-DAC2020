import java.util.Scanner;

public class Decimaltohexdecimal{
  public static void main(String[] args){
     Scanner scan = new Scanner(System.in);
     System.out.print("Enter a decimal number:");
     String a = scan.next();

     int b = Integer.parseInt(a,10);
  
     System.out.print("Hexdecimal number is:"+Integer.toHexString(b));

   }
}    
