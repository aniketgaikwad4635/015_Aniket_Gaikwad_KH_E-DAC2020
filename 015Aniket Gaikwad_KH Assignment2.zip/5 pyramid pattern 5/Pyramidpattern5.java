public class Pyramidpattern5{
     public static void main(String[] args){
           int n=9;
       for(int i=n;i>=1;i--){
          for(int k=i;k>1;k--){
            System.out.print("  ");
           }
          for(int j=i;j<=n;j++){
            System.out.print(j+" ");
          }
          for(int j=n-1;j>=i;j--){
            System.out.print(j+" ");
          }
        System.out.println();
       }
   } 
}  