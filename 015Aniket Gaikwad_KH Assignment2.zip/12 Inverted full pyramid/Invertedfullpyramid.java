public class Invertedfullpyramid{
    public static void main(String[] args){
         int n=6;
         for(int i=1;i<=n;i++){
           for(int k=1;k<i;k++){
               System.out.print(" ");
            }
           for(int j=i;j<=n;j++){
              if(i%2==1){
                if(j%2==1){
                System.out.print("*");
                }
                else {
                System.out.print(" ");
                }
              }
              else{
                if(j%2==0){
                System.out.print("*");
                }
                else {
                System.out.print(" ");
                }
              }
            } 
            for(int j=i;j<n;j++){
                    if(j%2==1){
                     System.out.print("*");
                     }
                    else {
                      System.out.print(" ");
                    }

             }      
            System.out.println();             
          }
      }
} 